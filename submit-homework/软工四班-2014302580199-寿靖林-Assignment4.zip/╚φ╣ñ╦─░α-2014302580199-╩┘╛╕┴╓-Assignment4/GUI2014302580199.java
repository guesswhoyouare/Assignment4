import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.event.*;

public class GUI2014302580199 extends JFrame {
	private JTextField text;
	private JButton buttonSearch;
	private JTextArea searchResultText;
	private JScrollPane jsp ;
	private static String searchKeyword;
	private TeacherInfo [] teacherInfo = new TeacherInfo[35];
	private int [] infoYes = new int[35];
	private int [] order = new int [35];
	
	public GUI2014302580199()
	{
		super("search tools");
		setLayout(null);
		
		text = new JTextField();
		add(text);
		text.setBounds(10, 10, 210, 20);
		
		buttonSearch = new JButton("search");
		add(buttonSearch);
		buttonSearch.setBounds(250, 10, 80, 20);
		
		searchResultText = new JTextArea();
		add(searchResultText);
		searchResultText.setBounds(10, 40, 370, 310);
		searchResultText.setEditable(false);
		
		jsp = new JScrollPane(searchResultText);
		add(jsp);
		jsp.setBounds(10, 40, 370, 310);
		
		ButtonHandler handler = new ButtonHandler();
		buttonSearch.addActionListener(handler);
	}
	
	private class ButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{		
			searchKeyword = text.getText();
			searchResultText.setText("");
			if(searchKeyword.trim().isEmpty())
			{
				searchResultText.append("null");
				return;
			}
			GetData data =new GetData();
			teacherInfo = data.getInfo();
			infoYes = data.getInfoYes();
			order = data.getOrder();
			
			
			
			int searchYes = 0;
			for(int i = 0;i<data.getCount();i++)
			{
				if(order[i] != -1)
				{
					if(infoYes[order[i]] == 1 )
					{
						String out = showInfo(order[i]);
						searchResultText.append(out);
						searchYes++;
					}
					
				}
			}
			searchResultText.append("����"+searchYes+"���������");
		}
	}

	public static String getKeyword()
	{
		return searchKeyword;
	}
	
	private String showInfo(int i)
	{
		String out = "";
		out = out
				+ teacherInfo[i].getName() + '\n'
				+ teacherInfo[i].getEducationBackground() + '\n'
				+ teacherInfo[i].getResearchInterests() + '\n'
				+ teacherInfo[i].getEmail() + '\n'
				+ teacherInfo[i].getPhone() + "\n\n";
		
		return out;
	}
}
