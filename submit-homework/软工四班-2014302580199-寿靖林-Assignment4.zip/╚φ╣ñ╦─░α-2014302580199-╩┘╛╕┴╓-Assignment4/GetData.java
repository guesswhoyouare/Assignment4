
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class GetData {
	private String driver = "com.mysql.jdbc.Driver";
	private String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
	private String username = "root";
	private String password = "123456";
	private int count = 0;
	
	private Connection con;

	private TeacherInfo [] teacherInfo = new TeacherInfo[35];
	private int [] infoYes = new int [35];
	
	private double [] TF = new double [35];
	private int [] order = new int [35];
	
	private void setConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName(driver);//��������mysql���ݿ������
		//��������
		con =
			DriverManager.getConnection(url,username,password);
	}
	
	GetData() 
	{
		for(int i =0;i<35;i++)
		{
			teacherInfo[i] = new TeacherInfo();
			infoYes[i] = 0;
			TF[i] = -1;
			order[i] = i;
		}
		String keyword = GUI2014302580199.getKeyword();
		try {
			setConnection();
			String search = "select * from 2014302580199_professor_info";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(search);
			int i = 0;
			while(rs.next())
			{
				teacherInfo[i].setName(rs.getString("name"));
				teacherInfo[i].setEducationBackground(rs.getString("educationBackground"));  
				teacherInfo[i].setResearchInterests(rs.getString("researchInterests"));
				teacherInfo[i].setEmail(rs.getString("email"));
				teacherInfo[i].setPhone(rs.getString("phone"));
				i++;
				count++;
			}

			rs.close();
			con.close();
			
			for(int j =0;j<count;j++)
			{
				if(teacherInfo[j].getName().trim().indexOf(keyword) != -1)
				{
					infoYes[j] = 1;
				}
				if(teacherInfo[j].getEducationBackground().trim().indexOf(keyword) != -1)
				{
					infoYes[j] = 1;
				}
				if(teacherInfo[j].getResearchInterests().trim().indexOf(keyword) != -1)
				{
					infoYes[j] = 1;
				}
				if(teacherInfo[j].getEmail().trim().indexOf(keyword) != -1)
				{
					infoYes[j] = 1;
				}
				if(teacherInfo[j].getPhone().trim().indexOf(keyword) !=-1)
				{
					infoYes[j] = 1;
				}
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		GetTF(keyword);
		sort();
	}
	
	public TeacherInfo[] getInfo()
	{
		return teacherInfo;
	}
	
	public int[] getInfoYes()
	{
		return infoYes;
	}
	
	public int getCount()
	{
		return count;
	}
	
	public void GetTF(String keyword)
	{
		String name;
		String educationBackground;
		String researchInterests;
		String email;
		String phone;
		
		int cnt = 0;
		for(int i =0;i<count;i++)
		{
			name = teacherInfo[i].getName();
			educationBackground = teacherInfo[i].getEducationBackground();
			researchInterests = teacherInfo[i].getResearchInterests();
			email = teacherInfo[i].getEmail();
			phone = teacherInfo[i].getPhone();
			
			while( name.indexOf(keyword)!= -1)
			{
				cnt++;
				name = name.substring(name.indexOf(keyword)+keyword.length());
			}
			while( educationBackground.indexOf(keyword)!= -1)
			{
				cnt++;
				educationBackground = educationBackground.substring(educationBackground.indexOf(keyword)+keyword.length());
			}
			while(researchInterests.indexOf(keyword)!= -1)
			{
				cnt++;
				researchInterests = researchInterests.substring(researchInterests.indexOf(keyword)+keyword.length());
			}
			while( email.indexOf(keyword)!= -1)
			{
				cnt++;
				email = email.substring(email.indexOf(keyword)+keyword.length());
			}
			while( phone.indexOf(keyword)!= -1)
			{
				cnt++;
				phone = phone.substring(phone.indexOf(keyword)+keyword.length());
			}
		TF[i] = (double)cnt*keyword.length()/(double)(name.length()
				+educationBackground.length()
				+researchInterests.length()
				+email.length()
				+phone.length());
		}
	}
	
	public void sort()
	{
		for(int i =0 ;i < count;i++)
		{
			for(int j = i+1;j<count;j++)
			{
				if(TF[i] < TF[j])
				{
					double temp = TF[i];
					TF[i] = TF[j];
					TF[j] = temp;
					int iTemp = order[i];
					order[i] = order[j];
					order[j] = iTemp;
				}
			}
		}
	}
	
	public int[] getOrder()
	{
		return order;
	}
}
