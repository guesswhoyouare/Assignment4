import javax.swing.JFrame;


public class Main2014302580199 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GUI2014302580199 gui = new GUI2014302580199();
		
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setSize(400, 400);
		gui.setVisible(true);
		
	}

}
